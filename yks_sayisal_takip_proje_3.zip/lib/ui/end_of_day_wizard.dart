import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../data/curriculum_data.dart';
import '../models/study_models.dart';
import '../providers/app_providers.dart';

class EndOfDayWizardModal extends ConsumerStatefulWidget {
  const EndOfDayWizardModal({super.key});

  @override
  ConsumerState<EndOfDayWizardModal> createState() =>
      _EndOfDayWizardModalState();
}

class _EndOfDayWizardModalState extends ConsumerState<EndOfDayWizardModal> {
  final List<StudySession> _draftQueue = [];

  RecordingMode _mode = RecordingMode.timeRange;
  SessionType _type = SessionType.topicStudy;
  TimeOfDay _start = const TimeOfDay(hour: 16, minute: 0);
  TimeOfDay _end = const TimeOfDay(hour: 17, minute: 30);

  String _subject = CurriculumData.allSubjects.first;
  String _topic =
      CurriculumData.sayisalCurriculum[CurriculumData.allSubjects.first]!.first;
  String _trialBranch = CurriculumData.branchTrialTypes.first;

  final _durCtrl = TextEditingController(text: '60');
  final _dCtrl = TextEditingController(text: '25');
  final _yCtrl = TextEditingController(text: '3');
  final _bCtrl = TextEditingController(text: '2');

  @override
  void dispose() {
    _durCtrl.dispose();
    _dCtrl.dispose();
    _yCtrl.dispose();
    _bCtrl.dispose();
    super.dispose();
  }

  String _fmt(TimeOfDay t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  int _calcDiff() {
    final s = _start.hour * 60 + _start.minute;
    final e = _end.hour * 60 + _end.minute;
    return (e - s) > 0 ? (e - s) : (e - s + 1440);
  }

  void _addToBatch() {
    final duration = _mode == RecordingMode.timeRange
        ? _calcDiff()
        : (int.tryParse(_durCtrl.text) ?? 45);

    final draft = StudySession(
      id: const Uuid().v4(),
      date: DateTime.now(),
      recordingMode: _mode,
      startTime: _mode == RecordingMode.timeRange ? _fmt(_start) : null,
      endTime: _mode == RecordingMode.timeRange ? _fmt(_end) : null,
      durationMinutes: duration,
      sessionType: _type,
      subject:
          _type == SessionType.topicStudy ? _subject : 'Branş Denemesi',
      topic: _type == SessionType.topicStudy ? _topic : _trialBranch,
      correctCount: int.tryParse(_dCtrl.text) ?? 0,
      wrongCount: int.tryParse(_yCtrl.text) ?? 0,
      emptyCount: int.tryParse(_bCtrl.text) ?? 0,
    );

    setState(() {
      _draftQueue.add(draft);
      _start = _end;
      _end = TimeOfDay(hour: (_end.hour + 1) % 24, minute: _end.minute);
    });
  }

  Future<void> _saveAll() async {
    if (_draftQueue.isEmpty) return;
    await ref
        .read(studySessionsProvider.notifier)
        .addMultipleSessions(_draftQueue);
    if (mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final topics = CurriculumData.sayisalCurriculum[_subject] ?? [];

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: MediaQuery.of(context).viewInsets.bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Gün Sonu Hızlı Giriş Sihirbazı',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                ),
              ],
            ),
            const Text(
              'Gün boyu yaptığınız tüm etütleri art arda listeye ekleyip tek tuşla kaydedin.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<SessionType>(
                    value: _type,
                    decoration: const InputDecoration(
                      labelText: 'Tür',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: SessionType.topicStudy,
                        child: Text('Konu / Soru'),
                      ),
                      DropdownMenuItem(
                        value: SessionType.branchTrial,
                        child: Text('Branş Denemesi'),
                      ),
                    ],
                    onChanged: (v) => setState(() => _type = v!),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<RecordingMode>(
                    value: _mode,
                    decoration: const InputDecoration(
                      labelText: 'Kayıt Modu',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    items: const [
                      DropdownMenuItem(
                        value: RecordingMode.timeRange,
                        child: Text('Saat Aralığı'),
                      ),
                      DropdownMenuItem(
                        value: RecordingMode.duration,
                        child: Text('Dakika Süre'),
                      ),
                    ],
                    onChanged: (v) => setState(() => _mode = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            if (_mode == RecordingMode.timeRange)
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final p = await showTimePicker(
                            context: context, initialTime: _start);
                        if (p != null) setState(() => _start = p);
                      },
                      child: Text('Başlangıç: ${_fmt(_start)}'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () async {
                        final p = await showTimePicker(
                            context: context, initialTime: _end);
                        if (p != null) setState(() => _end = p);
                      },
                      child: Text('Bitiş: ${_fmt(_end)}'),
                    ),
                  ),
                ],
              )
            else
              TextField(
                controller: _durCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: 'Süre (dk)',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
              ),
            const SizedBox(height: 10),
            if (_type == SessionType.topicStudy)
              Row(
                children: [
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _subject,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Ders',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: CurriculumData.allSubjects
                          .map((s) => DropdownMenuItem(value: s, child: Text(s)))
                          .toList(),
                      onChanged: (v) {
                        if (v != null) {
                          setState(() {
                            _subject = v;
                            _topic =
                                CurriculumData.sayisalCurriculum[v]!.first;
                          });
                        }
                      },
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: DropdownButtonFormField<String>(
                      value: _topic,
                      isExpanded: true,
                      decoration: const InputDecoration(
                        labelText: 'Konu',
                        border: OutlineInputBorder(),
                        isDense: true,
                      ),
                      items: topics
                          .map((t) => DropdownMenuItem(value: t, child: Text(t)))
                          .toList(),
                      onChanged: (v) {
                        if (v != null) setState(() => _topic = v);
                      },
                    ),
                  ),
                ],
              )
            else
              DropdownButtonFormField<String>(
                value: _trialBranch,
                isExpanded: true,
                decoration: const InputDecoration(
                  labelText: 'Deneme Branşı',
                  border: OutlineInputBorder(),
                  isDense: true,
                ),
                items: CurriculumData.branchTrialTypes
                    .map((b) => DropdownMenuItem(value: b, child: Text(b)))
                    .toList(),
                onChanged: (v) {
                  if (v != null) setState(() => _trialBranch = v);
                },
              ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _dCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Doğru',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _yCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Yanlış',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _bCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      labelText: 'Boş',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton.tonalIcon(
                  onPressed: _addToBatch,
                  icon: const Icon(Icons.playlist_add),
                  label: const Text('Ekle'),
                ),
              ],
            ),
            const Divider(height: 24),
            Text(
              'Kuyruktaki Oturumlar (${_draftQueue.length})',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            if (_draftQueue.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Henüz kuyruğa oturum eklenmedi.'),
              )
            else
              SizedBox(
                height: 150,
                child: ListView.builder(
                  itemCount: _draftQueue.length,
                  itemBuilder: (context, i) {
                    final item = _draftQueue[i];
                    return ListTile(
                      dense: true,
                      title: Text('${item.subject} - ${item.topic}'),
                      subtitle: Text(
                        '${item.durationMinutes} dk | ${item.totalQuestions} Soru (${item.net.toStringAsFixed(2)} Net)',
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.remove_circle_outline,
                            color: Colors.red),
                        onPressed: () =>
                            setState(() => _draftQueue.removeAt(i)),
                      ),
                    );
                  },
                ),
              ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _draftQueue.isEmpty ? null : _saveAll,
                icon: const Icon(Icons.check_circle),
                label: Text('Tümünü Kaydet (${_draftQueue.length} Oturum)'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
