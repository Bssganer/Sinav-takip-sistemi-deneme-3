import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/study_models.dart';
import '../providers/app_providers.dart';
import '../services/pdf_service.dart';

class ReportAndSettingsScreen extends ConsumerStatefulWidget {
  const ReportAndSettingsScreen({super.key});

  @override
  ConsumerState<ReportAndSettingsScreen> createState() =>
      _ReportAndSettingsScreenState();
}

class _ReportAndSettingsScreenState
    extends ConsumerState<ReportAndSettingsScreen> {
  late GoalType _goalType;
  late TextEditingController _targetCtrl;
  late TimeOfDay _reminderTime;

  @override
  void initState() {
    super.initState();
    final goal = ref.read(weeklyGoalProvider);
    _goalType = goal.goalType;
    _targetCtrl = TextEditingController(text: goal.targetValue.toString());
    _reminderTime =
        TimeOfDay(hour: goal.reminderHour, minute: goal.reminderMinute);
  }

  @override
  void dispose() {
    _targetCtrl.dispose();
    super.dispose();
  }

  Future<void> _saveSettings() async {
    final target = int.tryParse(_targetCtrl.text) ?? 25;
    final newGoal = WeeklyGoal(
      goalType: _goalType,
      targetValue: target > 0 ? target : 1,
      reminderHour: _reminderTime.hour,
      reminderMinute: _reminderTime.minute,
    );
    await ref.read(weeklyGoalProvider.notifier).updateGoal(newGoal);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Hedef ve bildirim saati güncellendi!'),
        ),
      );
    }
  }

  Future<void> _exportLandscapePdf() async {
    final weeklySessions = ref.read(currentWeekSessionsProvider);
    final redList = ref.read(redListProvider);
    final goal = ref.read(weeklyGoalProvider);
    final progress = ref.read(weeklyProgressProvider);

    final now = DateTime.now();
    final monday = DateTime(now.year, now.month, now.day)
        .subtract(Duration(days: now.weekday - 1));
    final sunday = monday.add(const Duration(days: 6));

    await PdfService.generateAndPreviewWeeklyReport(
      weekStart: monday,
      weekEnd: sunday,
      weeklySessions: weeklySessions,
      redList: redList,
      goal: goal,
      goalProgressPercent: progress,
    );
  }

  @override
  Widget build(BuildContext context) {
    final weeklySessions = ref.watch(currentWeekSessionsProvider);
    final totalMins =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.durationMinutes);
    final totalQs =
        weeklySessions.fold<int>(0, (sum, s) => sum + s.totalQuestions);

    return Scaffold(
      appBar: AppBar(
        title: const Text('PDF Raporu & Hedef Ayarları'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: Colors.indigo.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.picture_as_pdf,
                          color: Colors.indigo, size: 28),
                      SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'Yatay (Landscape) A4 Haftalık Analiz Karnesi',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Bu hafta kaydedilen ${weeklySessions.length} oturum ($totalMins dk, $totalQs soru), branş denemesi net eğrisi, Kırmızı Liste ve sayısal ders dağılımı tek sayfa yatay A4 formatında üretilir.',
                    style: const TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _exportLandscapePdf,
                      icon: const Icon(Icons.print),
                      label: const Text('Yatay A4 PDF Raporu Üret & Paylaş'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Haftalık Hedef Yapılandırması',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  SegmentedButton<GoalType>(
                    segments: const [
                      ButtonSegment(
                        value: GoalType.hours,
                        label: Text('Saat Hedefi'),
                        icon: Icon(Icons.schedule),
                      ),
                      ButtonSegment(
                        value: GoalType.questions,
                        label: Text('Soru Hedefi'),
                        icon: Icon(Icons.quiz),
                      ),
                    ],
                    selected: {_goalType},
                    onSelectionChanged: (val) =>
                        setState(() => _goalType = val.first),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _targetCtrl,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: _goalType == GoalType.hours
                          ? 'Haftalık Hedef Süre (Saat)'
                          : 'Haftalık Hedef Soru Sayısı',
                      border: const OutlineInputBorder(),
                    ),
                  ),
                  const Divider(height: 28),
                  const Text(
                    'Gün Sonu Hatırlatıcı Bildirimi',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.notifications_active,
                        color: Colors.indigo),
                    title: const Text('Gün Sonu Giriş Sihirbazı Saati'),
                    subtitle: const Text(
                        'Bildirime tıklandığında hızlı giriş ekranı açılır.'),
                    trailing: OutlinedButton(
                      onPressed: () async {
                        final picked = await showTimePicker(
                          context: context,
                          initialTime: _reminderTime,
                        );
                        if (picked != null) {
                          setState(() => _reminderTime = picked);
                        }
                      },
                      child: Text(
                        '${_reminderTime.hour.toString().padLeft(2, '0')}:${_reminderTime.minute.toString().padLeft(2, '0')}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _saveSettings,
                      icon: const Icon(Icons.save),
                      label: const Text('Ayarları Kaydet ve Bildirimi Kur'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
