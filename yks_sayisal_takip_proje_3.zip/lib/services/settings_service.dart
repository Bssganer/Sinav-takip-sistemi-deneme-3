import 'package:shared_preferences/shared_preferences.dart';
import '../models/study_models.dart';

class SettingsService {
  static const String _keyGoalType = 'goal_type';
  static const String _keyTargetValue = 'target_value';
  static const String _keyReminderHour = 'reminder_hour';
  static const String _keyReminderMinute = 'reminder_minute';

  final SharedPreferences _prefs;

  SettingsService(this._prefs);

  WeeklyGoal loadGoalSettings() {
    final typeIndex = _prefs.getInt(_keyGoalType) ?? 0;
    final target = _prefs.getInt(_keyTargetValue) ?? 25;
    final hour = _prefs.getInt(_keyReminderHour) ?? 23;
    final minute = _prefs.getInt(_keyReminderMinute) ?? 0;

    return WeeklyGoal(
      goalType: GoalType.values[typeIndex],
      targetValue: target,
      reminderHour: hour,
      reminderMinute: minute,
    );
  }

  Future<void> saveGoalSettings(WeeklyGoal goal) async {
    await _prefs.setInt(_keyGoalType, goal.goalType.index);
    await _prefs.setInt(_keyTargetValue, goal.targetValue);
    await _prefs.setInt(_keyReminderHour, goal.reminderHour);
    await _prefs.setInt(_keyReminderMinute, goal.reminderMinute);
  }
}
